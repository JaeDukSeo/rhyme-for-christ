The text in figaro.txt is from MF DOOM's Figaro,
All rights are reserved by the origial artist of the lyrics.

The dictionary created in figaro_highlights.py is derived from source material
from the youtube video: "MF DOOM - Figaro | Rhymes Highlighted"
created by youtube user "Highlighted"
