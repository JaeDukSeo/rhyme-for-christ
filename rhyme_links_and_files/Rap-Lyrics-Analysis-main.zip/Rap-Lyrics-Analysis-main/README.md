# Rap-Lyrics-Analysis
A larger project that will combine several projects in order to analyze rap lyrics based on their lyrics, the rhymes, and much more. 
